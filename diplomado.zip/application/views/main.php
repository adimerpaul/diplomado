<div class="page-content">
    <div class="page-header">
    <h1>
        <?=$title?>
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            pagina principal
        </small>
    </h1>
    </div>
</div>